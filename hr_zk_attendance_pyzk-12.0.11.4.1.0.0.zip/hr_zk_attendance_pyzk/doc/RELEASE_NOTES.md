## Module <hr_zk_attendance_pyzk>

#### 24.04.2019
#### Version 11.0.1.0.0
##### ADD
- Initial commit

#### 27.10.2019
#### Version 11.1.1.0.0
##### ADD
- Modified the code to work with pyzk library instead of zklib.

#### 31.10.2019
#### Version 11.2.1.0.0
##### ADD
- Added Feature to check connection to device & Unique constraint to device_id.

#### 06.11.2019
#### Version 11.3.1.0.0
##### ADD
- Added index.html and images for the module.

#### 12.11.2019
#### Version 11.4.1.0.0
##### ADD
 - Added Time After Field + TimeOut(seconds)
 