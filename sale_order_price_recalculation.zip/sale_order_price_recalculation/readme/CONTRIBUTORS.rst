* Carlos Sánchez Cifuentes <csanchez@grupovermon.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pierre Verkest <pverkest@anybox.fr>
* Vicent Cubells <vicent.cubells@tecnativa.com>
* David Vidal <david.vidal@tecnativa.com>
* Duc, Dao Dong <duc.dd@komit-consulting.com> (https://komit-consulting.com)
* Raf Ven <raf.ven@dynapps.be>
