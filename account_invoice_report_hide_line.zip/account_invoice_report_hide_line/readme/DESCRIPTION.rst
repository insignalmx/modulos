In some service companies, the customer is invoiced for a service that may consume inventory items. Those inventory items needs to be invoiced to account in the cost of services sold and reconcile the value of the inventory items delivered and sitting in the Un-Invoiced Goods Delivered, but they should not appear to the customer on the PDF report of their invoice.

This module allows you to hide invoice lines from the PDF report if the unit price is 0.
