# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.osv import expression

from lxml import etree


class ProductTemplate(models.Model):
    _inherit = "product.template"

    user_ids = fields.Many2many('res.users', string="Salesperson")


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    template_ids = fields.Binary(compute='product_filter')

    @api.onchange('user_id')
    def product_filter(self):
        product_template_id_lst = []
        for rec in self:
            if self.user_id:
                product_template_ids = self.env['product.template'].search([])
                for product_template_id in product_template_ids:
                    if not product_template_id.user_ids or self.user_id.id in product_template_id.user_ids.ids:
                        product_template_id_lst.append(product_template_id.id)
                rec.template_ids = product_template_id_lst
            else:
                rec.template_ids = product_template_id_lst

    @api.model
    def _fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
        """ fields_view_get([view_id | view_type='form'])

        Get the detailed composition of the requested view like fields, model, view architecture

        :param int view_id: id of the view or None
        :param str view_type: type of the view to return if view_id is None ('form', 'tree', ...)
        :param bool toolbar: true to include contextual actions
        :param submenu: deprecated
        :return: composition of the requested view (including inherited views and extensions)
        :rtype: dict
        :raise AttributeError:
                * if the inherited view has unknown position to work with other than 'before', 'after', 'inside', 'replace'
                * if some tag other than 'position' is found in parent view
        :raise Invalid ArchitectureError: if there is view type other than form, tree, calendar, search etc defined on the structure
        """
        res = super(SaleOrder, self)._fields_view_get(view_id, view_type, toolbar, submenu)
        parent = self
        new_domain = "[('product_tmpl_id', 'in',parent.template_ids )]"

        if view_type == 'form':
            XML_arch = etree.XML(res.get('arch'))
            nodes = XML_arch.xpath("//field[@name='order_line']/tree/field[@name='product_id']")

            for node_item in nodes:
                domain = new_domain
                node_item.set('domain', str(domain))
            templ_nodes = XML_arch.xpath("//field[@name='order_line']/tree/field[@name='product_template_id']")
            templ_new_domain = "[('id', 'in',parent.template_ids )]"
            for templ_node_item in templ_nodes:
                domain = templ_new_domain
                templ_node_item.set('domain', str(domain))
            res.update(arch=etree.tostring(XML_arch))

        return res
