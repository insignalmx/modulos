# -*- coding: utf-8 -*-
{
    'name': "Salesperson Own Products",

    'summary': """Set own products for each salesperson""",

    'description': """
         By using this app you can set specific salesperson for a product. Means, while creating
                                a sale order the salesperson will only see the specified products. 
                                Salesperson can also see those products, for which any salesperson is not assigned.
                                This will help you to filtering the products.
    """,

    'author': "ErpMstar Solutions",
    'category': 'Sales',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['sale_management'],

    # always loaded
    'data': [
        'views/views.xml',

    ],
    # only loaded in demonstration mode
    'demo': [
    ],
    'images': ['static/description/banner.png'],
    'installable': True,
    'application': True,
    'price': 15,
    'currency': 'EUR',
}
