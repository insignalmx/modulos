How to use this addon?
==============

It's very easy. Just select from checkboxes for control columns and select Print image checkbox and select image size for print product image.

If you have any questions then you can contact us via following email. Support email: almas@dusal.net



.. image:: https://dusal.net/other/odoo/dusal_sale/main_screenshot.png
